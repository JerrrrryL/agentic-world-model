"""Pull upstream trajectory releases into ``raw/``.

Each fetcher is idempotent: re-running it resumes rather than re-downloads, so
a batch can be widened without paying for what is already on disk.

Sizes, measured 2026-08-24:

*   PI speedrun — 41 runs, 50 MB. The whole release; no reason to subset.
*   PostTrainBench — 1,842 runs, 28.9 GB in full. The default batch takes four
    agent configurations across the five core benchmarks, and only the files an
    analysis needs (0.59 GB): the ``task/`` workspace snapshots and the
    multi-hundred-MB ``error.log``s stay upstream until something needs them.
"""

from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from hv.paths import ensure, raw_dir

PI_REPO = "https://github.com/PrimeIntellect-ai/frontier-automated-speedrun"
PTB_DATASET = "aisa-group/PostTrainBench-Trajectories"

#: The five objectively-scored PostTrainBench benchmarks. The two LLM-judged
#: ones (arenahardwriting, healthbench) are the observation group and are
#: fetched only when asked for.
PTB_CORE_BENCHMARKS = ("aime2025", "gsm8k", "gpqamain", "humaneval", "bfcl")
PTB_OBSERVE_BENCHMARKS = ("arenahardwriting", "healthbench")

#: Per-run files worth having. Deliberately excludes ``task/`` (workspace
#: snapshot) and ``error.log`` (up to 162 MB, mostly duplicate stderr).
PTB_RUN_FILES = (
    "solve_out.txt",  # the native CLI JSONL — the trajectory itself
    "solve_parsed.txt",  # upstream's human-readable rendering, used to cross-check
    "metrics.json",
    "time_taken.txt",
    "judgement_gpt5_4.json",  # contamination / disallowed-model verdict
    "system_monitor.log",  # 60 s samples of GPU util, memory, disk
)

#: First batch: two Claude Code and two Codex configurations, matched roughly in
#: size, covering the top of the leaderboard and the models we already validated
#: the parsers against.
PTB_DEFAULT_CONFIGS = (
    "claude_non_api_max_claude-opus-4-8_10h_run1",
    "claude_non_api_max_claude-fable-5_1m__10h_run1",
    "codex_non_api_high_gpt-5.4_10h_run1",
    "codex_non_api_max_gpt-5.6-sol_10h_run1",
)

#: Sentinel for "every agent configuration in the release". Measured over the
#: published file list: all 62 configurations, all 7 benchmarks, trace files
#: only, is 7.30 GB / 1,842 runs — the whole analysable corpus. The other 21.6 GB
#: of the release is workspace snapshots (10.6 GB), pre-parsed viewer JSON
#: (5.3 GB, redundant with the traces) and error logs (1.5 GB).
ALL_CONFIGS: tuple[str, ...] = ()


@dataclass
class FetchResult:
    source: str
    path: Path
    n_files: int
    bytes: int

    def __str__(self) -> str:
        return f"{self.source}: {self.n_files} files, {self.bytes / 1e9:.2f} GB at {self.path}"


def _tree_size(path: Path) -> tuple[int, int]:
    n = 0
    total = 0
    for p in path.rglob("*"):
        if p.is_file():
            n += 1
            total += p.stat().st_size
    return n, total


def fetch_pi(dest: Path | None = None) -> FetchResult:
    """Clone the PI speedrun release (shallow). Re-run to update in place."""
    dest = dest or raw_dir("pi_speedrun")
    ensure(dest.parent)
    if (dest / ".git").exists():
        subprocess.run(["git", "-C", str(dest), "fetch", "--depth", "1", "origin"], check=True)
        subprocess.run(["git", "-C", str(dest), "reset", "--hard", "origin/HEAD"], check=True)
    else:
        subprocess.run(
            ["git", "clone", "--depth", "1", PI_REPO, str(dest)],
            check=True,
        )
    n, total = _tree_size(dest)
    return FetchResult("pi_speedrun", dest, n, total)


def ptb_list_files(cache: Path | None = None) -> list[tuple[str, int]]:
    """Every ``(path, size)`` in the dataset, from the paginated tree API.

    ``snapshot_download(allow_patterns=...)`` is unusable here: on a repo with
    218k files it sat for ten minutes without writing anything. Listing the tree
    ourselves takes about 25 s (1000 entries per page) and lets us select exact
    paths, so downloads start immediately. The listing is cached, since it only
    changes when upstream publishes more runs.
    """
    import requests

    cache = cache or (raw_dir("posttrainbench") / ".file_list.json")
    if cache.exists():
        return [(p, s) for p, s in json.loads(cache.read_text())]

    from huggingface_hub import get_token

    token = get_token()
    headers = {"Authorization": f"Bearer {token}"} if token else {}
    url = f"https://huggingface.co/api/datasets/{PTB_DATASET}/tree/main"
    params: dict[str, Any] = {"recursive": "true", "limit": 1000}
    out: list[tuple[str, int]] = []
    while url:
        r = requests.get(url, headers=headers, params=params, timeout=60)
        r.raise_for_status()
        out.extend((e["path"], e.get("size", 0)) for e in r.json() if e.get("type") == "file")
        # The next page arrives as a fully-formed URL in the Link header.
        link = r.headers.get("Link", "")
        url = link.split(">;")[0].lstrip("<") if 'rel="next"' in link else ""
        params = {}
    ensure(cache.parent)
    cache.write_text(json.dumps(out))
    return out


def ptb_select(
    all_files: list[tuple[str, int]],
    configs: tuple[str, ...] = PTB_DEFAULT_CONFIGS,
    benchmarks: tuple[str, ...] = PTB_CORE_BENCHMARKS,
    files: tuple[str, ...] = PTB_RUN_FILES,
) -> list[tuple[str, int]]:
    """Pick ``<config>/<benchmark>_<org>_<model>_<cluster>/<file>`` paths.

    An empty ``configs`` means every configuration (``ALL_CONFIGS``); an empty
    ``benchmarks`` or ``files`` selects nothing, since those are the filters that
    keep the download from being the whole 28.9 GB release.
    """
    cfg = set(configs)
    bench = set(benchmarks)
    want = set(files)
    picked = []
    for path, size in all_files:
        parts = path.split("/")
        if len(parts) != 3 or parts[2] not in want:
            continue
        if cfg and parts[0] not in cfg:
            continue
        if parts[0] == "viewer_data":
            continue
        if parts[1].split("_")[0] in bench:
            picked.append((path, size))
    return picked


def fetch_posttrainbench(
    dest: Path | None = None,
    configs: tuple[str, ...] = PTB_DEFAULT_CONFIGS,
    benchmarks: tuple[str, ...] = PTB_CORE_BENCHMARKS,
    files: tuple[str, ...] = PTB_RUN_FILES,
    workers: int = 12,
    progress_every: int = 50,
) -> FetchResult:
    """Download a subset of the PostTrainBench trajectory dataset.

    Apache-2.0 and not gated, so no token is required; one is used if present.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    from huggingface_hub import hf_hub_download

    dest = dest or raw_dir("posttrainbench")
    ensure(dest)
    wanted = ptb_select(ptb_list_files(), configs, benchmarks, files)
    todo = [(p, s) for p, s in wanted if not (dest / p).exists()]
    print(
        f"posttrainbench: {len(wanted)} files selected "
        f"({sum(s for _, s in wanted) / 1e9:.2f} GB), {len(todo)} to download"
    )

    def one(path: str) -> str:
        return hf_hub_download(
            repo_id=PTB_DATASET, repo_type="dataset", filename=path, local_dir=str(dest)
        )

    done = 0
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(one, p): p for p, _ in todo}
        for fut in as_completed(futures):
            fut.result()
            done += 1
            if done % progress_every == 0 or done == len(todo):
                print(f"  {done}/{len(todo)}", flush=True)

    n, total = _tree_size(dest)
    return FetchResult("posttrainbench", dest, n, total)


FETCHERS = {"pi_speedrun": fetch_pi, "posttrainbench": fetch_posttrainbench}
